<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:template match="/">

        <html>
            <head>
                <title>XY Órarend – 2026 II. félév.</title>

                <style>
                    body{
                    font-family: Arial;
                    background-color: #f0f8ff;
                    }

                    table{
                    border-collapse: collapse;
                    width: 100%;
                    }

                    th, td{
                    border: 1px solid black;
                    padding: 8px;
                    text-align: center;
                    }

                    th{
                    background-color: lightblue;
                    }

                    tr:nth-child(even){
                    background-color: #eeeeee;
                    }

                    h1{
                    text-align: center;
                    color: darkblue;
                    }
                </style>
            </head>

            <body>

                <h1>XY Órarend – 2026 II. félév.</h1>

                <table>

                    <tr>
                        <th>ID</th>
                        <th>Típus</th>
                        <th>Tárgy</th>
                        <th>Nap</th>
                        <th>Tól</th>
                        <th>Ig</th>
                        <th>Helyszín</th>
                        <th>Oktató</th>
                        <th>Szak</th>
                    </tr>

                    <xsl:for-each select="EYZWG9_orarend/ora">

                        <tr>
                            <td>
                                <xsl:value-of select="@id"/>
                            </td>

                            <td>
                                <xsl:value-of select="@tipus"/>
                            </td>

                            <td>
                                <xsl:value-of select="targy"/>
                            </td>

                            <td>
                                <xsl:value-of select="idopont/nap"/>
                            </td>

                            <td>
                                <xsl:value-of select="idopont/tol"/>
                            </td>

                            <td>
                                <xsl:value-of select="idopont/ig"/>
                            </td>

                            <td>
                                <xsl:value-of select="helyszin"/>
                            </td>

                            <td>
                                <xsl:value-of select="oktato"/>
                            </td>

                            <td>
                                <xsl:value-of select="szak"/>
                            </td>

                        </tr>

                    </xsl:for-each>

                </table>

            </body>
        </html>

    </xsl:template>

</xsl:stylesheet>